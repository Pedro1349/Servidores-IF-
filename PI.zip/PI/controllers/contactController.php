<?php

class contactController{

    public static function contact(){
        return Direction::render('/content/contact');
    }

}   