<?php
// Conexão com o banco de dados

function connection(){
    $servidor = “servidor”;
    $usuario = “kaua_pedro”;
    $senha = “123456789”;
    $basededados = “servidor”;

    $conexao = new mysqli($servidor, $usuario, $senha,
    $basededados);

    if($conexao->connect_errno) {
    echo “Falha ao conectar: (” . $conexao->connect_errno . “)”
    . $conexao->connect_error;
}
}

    